/**
 * @param {string} jewels
 * @param {string} stones
 * @return {number}
 */
function numJewelsInStones (jewels, stones) {
    
};

function main() {
    const jewels = process.argv[2];
	  const stones = process.argv[3];
    console.log(numJewelsInStones(jewels, stones));
}

main();