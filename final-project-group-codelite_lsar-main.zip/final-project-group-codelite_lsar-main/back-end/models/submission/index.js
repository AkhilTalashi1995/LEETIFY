import Submission from "./submission";

export default Submission;
