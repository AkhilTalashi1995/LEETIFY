import User from "./user.js";

export default User;
