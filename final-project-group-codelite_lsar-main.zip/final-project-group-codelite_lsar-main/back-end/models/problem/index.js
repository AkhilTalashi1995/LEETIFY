import Problem from "./problem.js";

export default Problem;
